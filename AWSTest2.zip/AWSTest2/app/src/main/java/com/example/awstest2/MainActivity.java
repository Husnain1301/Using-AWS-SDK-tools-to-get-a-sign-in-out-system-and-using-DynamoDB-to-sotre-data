package com.example.awstest2;

import androidx.appcompat.app.AppCompatActivity;

import com.amazonaws.auth.AWSCognitoIdentityProvider;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.auth.core.SignInStateChangeListener;
import com.amazonaws.mobile.auth.ui.SignInUI;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;
import com.amazonaws.mobile.config.AWSConfiguration;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.models.nosql.NotesDO;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.dynamodbv2.document.Table;
import com.amazonaws.mobileconnectors.dynamodbv2.document.UpdateItemOperationConfig;
import com.amazonaws.mobileconnectors.dynamodbv2.document.datatype.Document;
import com.amazonaws.mobileconnectors.dynamodbv2.document.datatype.Primitive;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private Button SignOutMain, SaveBtn;
    private EditText UserIDMA, NoteIDMA;
    private DynamoDBMapper dynamoDBMapper;
    String User_ID, Note_ID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AndroidUI();

        AWSMobileClient.getInstance().initialize(this, new AWSStartupHandler() {

            @Override
            public void onComplete(AWSStartupResult awsStartupResult) {
                AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient(AWSMobileClient.getInstance().getCredentialsProvider());
                dynamoDBMapper = DynamoDBMapper.builder()
                        .dynamoDBClient(dynamoDBClient)
                        .awsConfiguration(
                                AWSMobileClient.getInstance().getConfiguration())
                        .build();
            }
        }).execute();
        SignOutMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Signing you out", Toast.LENGTH_SHORT).show();
                IdentityManager.getDefaultIdentityManager().signOut();
                startActivity(new Intent(MainActivity.this, AuthenticatorActivity.class));
            }
        });
        SaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateNotes();
            }
        });
    }
    public void CreateNotes(){
        final com.amazonaws.models.nosql.NotesDO Notes = new com.amazonaws.models.nosql.NotesDO();
        User_ID = UserIDMA.getText().toString();
        Note_ID = NoteIDMA.getText().toString();
        Notes.setUserId(User_ID);
        Notes.setNoteId(Note_ID);
        new Thread(new Runnable() {
            @Override
            public void run() {
                dynamoDBMapper.save(Notes);
            }
        }).start();
    }
    public void AndroidUI(){
        SignOutMain = findViewById(R.id.LogOutBtnMain);
        SaveBtn = findViewById(R.id.SaveBtnMA);
        UserIDMA = findViewById(R.id.UserIDMA);
        NoteIDMA = findViewById(R.id.NoteIDMA);
    }
}

